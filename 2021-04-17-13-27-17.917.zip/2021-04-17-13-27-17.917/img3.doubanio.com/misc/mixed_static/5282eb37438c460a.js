





$(function(){
    var isManager = 'False' === 'True'

    $("#joingroupbtn").click(function(e){
        url = "/j/group/" + $(this).attr("name") + "/join";
        if(window._USER_ABNORMAL) {
            e.preventDefault()
            window.show_abnormal && window.show_abnormal()
            return
        }
        $.post_withck(url, {},
            function(sjson){
                var ret = eval("(" + sjson + ")");
                $("#joingroupbtn").hide();
                if (ret.result=="toomany"){
                    $("#replysect").html('<p class="attn" align="right">你已经加入了500个小组，无法再加入更多小组。</p>');
                }else{
                    $("#replysect").html('<br/><h2>你现在加入了这个小组，可以发表回应</h2><div class="txd comment-form"><form name="comment_form" method="post" action="add_comment"><textarea name="rv_comment" rows="8" cols="54"></textarea><br/><input type="hidden" name="start" value="0"/><span class="bn-flat-hot rr"><input type="submit" value="发送"/></span><span><label class="pl share-label share-shuo"><input type="checkbox" name="sync_to_mb"/>转发到广播 </label> </span></form></div>');
                }
            });
        return false;
    });

    $(".topic-reply li").find('.operation-more').hide()
    $(".topic-reply li").find('.lnk-show-memberstats').remove();

    $(".topic-reply li").bind('mouseenter mouseleave click', function (e) {
        var $this = $(this),
            comment_user_id = $this.find(".operation_div").attr("id"),
            can_delete = 0;
        if (comment_user_id == 59561039){
            can_delete = 1;
        }
        if (can_delete==1){
            $this.find(".lnk-delete-comment").show();
        } else {
            $this.find(".lnk-delete-comment").remove()
        }
        if (can_delete !== 1 && !isManager) {
            $this.find('.lnk-opt-line').remove()
        } else {
            $this.find('.lnk-opt-line').show()
        }
        switch (e.type) {
            case "mouseenter":
                $this.find(".operation-more").show();
                break;
            case "mouseleave":
                $this.find(".operation-more").hide();
                break;
        }
    });

    $(function(){
        var req_user_id = 59561039;
        var expand_text_length = 90;

        // 主评论的 private
        $(".comment-private").each(function(index, el){
            var $el = $(el);
            var author_id = $el.data('author-id');
            if(author_id === req_user_id){
            $el.addClass('comment-private-author');
            }
        });

        // 引用评论的 private
        $(".reply-quote-private .reply-quote-content").each(function(index, el){
            var $el = $(el);
            var author_id = $el.data('author-id');

            if(author_id === req_user_id){
            var real_text = $el.find('.real-text').html();

            $el.find('.all').html(real_text);
            $el.find('.short').html(real_text.slice(0, expand_text_length));

            if(real_text.length > expand_text_length){
                $el.find('.toggle-reply').html('<span class="expaned">...</span>');
            }
            }
        });

    });


    $('body').delegate('.reply-comment .lnk-close', 'click', function(e){
      e.preventDefault();
      $(this).parent().remove();
    });

});

$(".reply-quote-private").mouseenter(function() {
    $(this).find('.private-msg').show()
}).mouseleave(function() {
    $(this).find('.private-msg').hide()
})
;
    Do = (typeof Do === 'undefined')? $ : Do;
    Do(function(){
      var reportDiv = "#link-report".concat("_group");
      $("body").delegate(reportDiv, 'mouseenter mouseleave', function(e){

        switch (e.type) {
          case "mouseenter":
            $(this).find(".report").css('visibility', 'visible');
            break;
          case "mouseleave":
            $(this).find(".report").css('visibility', 'hidden');
            break;
        }
      });
      $(reportDiv).delegate(".report a", 'click', function(e){
          e.preventDefault();
          var auditUrl = "http://www.douban.com/misc/audit_report?url=",
              opt = "";
          var obj = $(e.target).closest(reportDiv);
          var id = obj.length != 0 ? obj.data("id") : undefined;
          var params = (opt&&id) ? '?'.concat(opt, '=', id) : '';
          var url = "https://www.douban.com/group/topic/221530182/".concat(params);
          generate_report_dialog({report_url: url});
      });

      $(reportDiv).append('<div class="report"><a rel="nofollow" href="javascript:void(0)">投诉</a></div>');
  });
;
    "use strict";$(function(){function t(t,e){var a=t.text(),r=a?parseInt(a):0;r+=e,r>0?t.text(r):0===r&&t.text("")}var e="https://m.douban.com/rexxar/api/v2/";$(".react-btn").bind("click",function(a){if(window._USER_ABNORMAL)return void(show_abnormal&&show_abnormal());var r=$(this),n=r.find(".react-text"),i=r.find(".react-num"),o=r.data(),c=void 0;c=0===o.reaction_type?1:0;var s={reaction_type:c,ck:get_cookie("ck")},d=""+e+o.type+"/"+o.object_id+"/react";$.ajax({type:"post",url:d,data:s,traditional:!0,beforeSend:function(t){t.withCredentials=!0},xhrFields:{withCredentials:!0},success:function(e){r.data("reaction_type",e.reaction_type),1===e.reaction_type?(t(i,1),n.text("已赞"),r.removeClass("react-add").addClass("react-cancel")):(t(i,-1),n.text("赞"),r.removeClass("react-cancel").addClass("react-add"))},error:function(t){try{var e=JSON.parse(t.response);e.extra&&e.extra.solution_uri&&(window.location.href=e.extra.solution_uri)}catch(t){}}})})});
    "use strict";function show_doulist_remind(){var e="         <div id='doulist-new-function-remind'>             <div class='title'>“喜欢”升级啦</div>             <div class='desc'>觉得内容不错，点个赞吧；</br>想Mark，收藏到豆列是最好的选择</div>             <button class='i_know'>我知道了</button>         </div>     ",o=document.createElement("DIV");o.innerHTML=e,o=o.firstElementChild;var t=document.querySelector(".action-react"),i=t.querySelector(".react-add");if(t&&get_cookie("ck")&&(!i||!i.classList.contains("a_show_login"))){t.style.position="relative",t.appendChild(o);var n=document.querySelector(".i_know");n.addEventListener("click",close_doulist_remind)}}function close_doulist_remind(){var e=document.getElementById("doulist-new-function-remind");e&&e.remove()}!function(){localStorage&&localStorage.getItem("douban-fav-remind")||get_cookie&&get_cookie("douban-fav-remind")||(show_doulist_remind(),localStorage&&localStorage.setItem("douban-fav-remind","1"),set_cookie&&set_cookie({"douban-fav-remind":1},36500,"douban.com","/"))}();
;
(function(){
    window.collect_target = {
        tkind: "1013",
        tid: "221530182"
    }
    window.update_collect_state = function(collected){
        var ele = document.querySelector('.lnk-doulist-add');
        var old_num = parseInt(ele.querySelector('.react-num').textContent);
        ele.className = 'lnk-doulist-add';
        if(collected){
            ele.className += ' collect-cancel';
            ele.querySelector('.react-text').textContent = '已收藏';
            ele.querySelector('.react-num').textContent = isNaN(old_num) ? 1 : old_num + 1;
        }else{
            ele.className += ' collect-add';
            ele.querySelector('.react-text').textContent = '收藏';
            ele.querySelector('.react-num').textContent = isNaN(old_num) ? "" : old_num - 1 === 0 ? "" : old_num - 1;
        }
    }
})();
function deferred(){var e={done:[],fail:[]},t={done:function(o){return e.done.push(o),t},fail:function(o){return e.fail.push(o),t}};return{resolve:function(){for(var t,o=0;t=e.done[o++];)t.apply(this,arguments)},reject:function(){for(var t,o=0;t=e.fail[o++];)t.apply(this,arguments)},promise:t}}var loader=function(e,t,o,r,n,a){if(e){"function"==typeof t&&(r=t,t=""),"function"==typeof o&&(r=o,o="");var i=function(){loader.loaded[e]=1,r&&r(e),r=null,clearTimeout(d)};if(loader.loaded[e])return loader.loading[e]&&(loader.loading[e]=0),void setTimeout(function(){i()},0);if(loader.loading[e])return void setTimeout(function(){loader(e,t,o,r,n,a)},10);loader.loading[e]=1;var l,d=setTimeout(function(){try{a(e)}catch(e){}},n||6e3),s=t||e.toLowerCase().split(/\./).pop().replace(/[\?#].*/,"");"js"===s?(l=document.createElement("script"),l.setAttribute("type","text/javascript"),l.setAttribute("src",e),l.setAttribute("async",!0)):"css"===s&&(l=document.createElement("link"),l.setAttribute("type","text/css"),l.setAttribute("rel","stylesheet"),l.setAttribute("href",e)),o&&(l.charset=o),"css"===s?setTimeout(function(){i()},0):(l.onerror=function(){i(),l.onerror=null},l.onload=l.onreadystatechange=function(){this.readyState&&"loaded"!==this.readyState&&"complete"!==this.readyState||(setTimeout(function(){i()},0),l.onload=l.onreadystatechange=null)});var c=function(){var e=document.getElementsByTagName("script");return e[e.length-1]}();c.parentNode.insertBefore(l,c)}};loader.loaded=window.__external_files_loaded=window.__external_files_loaded||{},loader.loading=window.__external_files_loading=window.__external_files_loading||{},loader.batch=function(){if(0!=arguments.length){var e=Array.prototype.slice.call(arguments);"[object Array]"==Object.prototype.toString.call(e[0])&&(e=e[0]);for(var t,o=deferred(),r=[],n=function(){r.pop(),0===r.length&&o.resolve()},a=0;t=e[a++];)r.push(t),loader(t,n);return o.promise}};
Do(function() {
  loader.batch([
    'https://img3.doubanio.com/f/shire/8377b9498330a2e6f056d863987cc7a37eb4d486/css/ui/dialog.css',
    'https://img3.doubanio.com/f/shire/383a6e43f2108dc69e3ff2681bc4dc6c72a5ffb0/js/ui/dialog.js'
  ]).done(function() {
    var encodeHTML = function(s) {
    return s.replace(/\&/g, '&amp;')
            .replace(/\"/g, '&quot;')
            .replace(/\'/g, '&apos;')
            .replace(/\</g, '&lt;')
            .replace(/\>/g, '&gt;');
};

function deferred() {
  var callbacks = {
    done: [],
    fail: []
  };

  var promise = {
    done: function(callback) {
      callbacks.done.push(callback);
      return promise;
    },

    fail: function(callback) {
      callbacks.fail.push(callback);
      return promise;
    }
  };

  return {
    resolve: function() {
      var i = 0, cb;
      for(;cb = callbacks['done'][i++];) {
        cb.apply(this, arguments);
      }
    },

    reject: function() {
      var i = 0, cb;
      for(;cb = callbacks['fail'][i++];) {
        cb.apply(this, arguments);
      }
    },

    promise: promise 
  };
}
;
function asyncRequest(url, params, method) {
  var defer = deferred();
  var xhr = null;
  var t = (method || 'get').toLowerCase();
  xhr = $.ajax({
    url: url,
    type: t, 
    dataType: 'json',
    data: (t === 'post')? $.extend(params, {ck: get_cookie('ck')}) : params,
    error: function(e) {
      defer.reject(e);
    },
    success: function(e) {
      defer.resolve(e);
    }
  });

  defer.promise.abort = function() {
    xhr && xhr.abort();
  }
  return defer.promise;
}
;
var DOULIST_ADDITEM = '/j/doulist/{doulist_id}/additem';
var DOULIST_REMOVEITEM = '/j/doulist/{doulist_id}/removeitem';
var DOULIST_EDITITEM = '/j/doulist/{doulist_id}/edititem';
var DOULIST_COMMENT = '/j/doulist/{doulist_id}/poke';
var DOULIST_CREATE = '/j/doulist/add';
var DOULIST_LIST = '/j/doulist/cat';
var DOULIST_SEARCH = '/j/doulist/search';
var DOULIST_SEARCH_SELF = '/j/doulist/search_user_doulists';
var DOULIST_GET_ITEM_INFO = '/j/doulist/get_item_info';
var SUBJECT_DOULIST_LIST = '/j/doulist/subject_doulists'; // 片单|书单
;
var validateForm = function(frm, rules) {
  var bool = true;
  var inp;
  for (var n in rules) {
    if (rules.hasOwnProperty(n)) {
      inp = frm.find(n);
      bool = rules[n](inp);
      if (bool) {
        validateForm.cleanError(inp);
      }
    }
  }
  return bool;
};

validateForm.displayError = function(inp, error) {
  if (!inp) {
    return;
  }
  var item = inp.closest('.item');
  var errorNode = item.find('.form-field-error');
  if (errorNode.length === 0) {
    errorNode = $('<div class="form-field-error"></div>').prependTo(item);
  }
  errorNode.show().html(error);
};

validateForm.cleanError = function(inp) {
  inp.closest('.item').find('.form-field-error').hide();
};



function doulistCustomeEvents(dialog) {
  var cancelBtn = dialog.node.find('.bn-cancel');
  dialog.node.bind('dialog-error', function(e, error) {
    dialog.setContent(
      '<div class="doulist-submit-success"><p>' + error + '</p>\
         <div class="item-submit">\
           <span class="bn-flat"><input type="button" value="关闭" class="bn-cancel"></span>\
         </div>\
       </div>\
      '
    ).update();
    cancelBtn.click(function() {
      dialog.close();
    });
    setTimeout(function() {
      dialog.close();
    }, 3000);
  });

  dialog.node.bind('dialog-success', function(e, doulist) {
    title = doulist.__title || "添加成功"
    action = doulist.__action || '已经添加到<a href="' + doulist.url + '" target="_blank"> ' + doulist.name + '</a>';
    dialog.setTitle(title).setContent(
      '<div class="doulist-submit-success">\
         <i></i>' + action + '\
         <div>\
           <p>窗口将在<b class="num">3</b>秒后关闭</p>\
           <span class="bn-flat"><input type="button" value="关闭" class="bn-cancel"></span>\
         </div>\
       </div>\
      '
    );
    cancelBtn = dialog.node.find('.bn-cancel');
    cancelBtn.click(function() {
      dialog.close();
      timer && clearTimeout(timer);
    });
    var num = dialog.node.find('.num')
      , count = num.text()
      , countdown, timer
    ;(function() {
      countdown = countdown || arguments.callee;
      timer = setTimeout(function() {
        num.text(--count);
        count? countdown(): dialog.close();
      }, 1000);
    })();
  });
}
;
var doulistDialogForm = typeof doulistDialogForm === 'undefined'? {} : doulistDialogForm

;(function() {
  var initForm = function(dialog) {
    var frm = dialog.node.find('form');

    frm.submit(function(e){
      e.preventDefault();
      var frmData = {
        subjectId: frm.find('input[name=subject_id]').val(),
        subjectKind: frm.find('input[name=subject_kind]').val(),
        subjectUrl: frm.find('input[name=subject_url]').val(),
        subjectIsUrlSubject: frm.find('input[name=subject_is_url_subject]').val() == "true",
        comment: frm.find('textarea[name="comment"]').val(),
        sync: frm.find('#dlg-opt-share').attr('checked')? '1': ''
      };
      existListHandler(dialog, frm, frmData)
        .bind('form-submit-error', function(e, error) {
          dialog.node.trigger('dialog-error', error);
        })
        .bind('form-submit-success', function(e, doulist) {
          dialog.node.trigger('dialog-success', doulist);
        })
    });
    frm.bind('form-submit-fail', function(e, msg){
      validateForm.displayError(frm.find('input[name=dl_title]'), msg);
    });
    doulistCustomeEvents(dialog);
  }

  function existListHandler(dialog, frm, frmData) {
    var doulistSelect = frm.find('input[name=dl_id]:checked');
    var doulistId = doulistSelect.val();
    var doulistName = doulistSelect.next().find('b').text();
    var validateRules = {
      '.dl_exist_select input:checked': function(e) {
        if (!e.length) {
          validateForm.displayError($('.dl_exist_select'), '请选择一个豆列');
          return false;
        }
        return true;
      }
    }
    if(!doulistId && window.hasCancelCollectAction === true){
      var obj = {
        __title: "取消收藏成功",
        __action: "已经取消了收藏"
      }
      setTimeout(function(){
        frm.trigger('form-submit-success', obj);
      }, 500)
      window.update_collect_state && window.update_collect_state(false);
      window.hasCancelCollectAction = null;
      return frm;
    }
    if (validateForm(frm, validateRules)) {
      var data = {
        /* local-dev
        // sid: '25839662', // movie
        // sid: '24879016', // book
        */
        sid: frmData.subjectId,
        skind: frmData.subjectKind,
        comment: frmData.comment,
        sync_to_mb: frmData.sync
      }
      if(frmData.subjectIsUrlSubject){
        data.surl = frmData.subjectId
        delete data.sid
        delete data.skind
      }
      asyncRequest(
        DOULIST_ADDITEM.replace('{doulist_id}', doulistId),
        data,
        'post'
      ).done(function(res) {
        if (res.r) {
          frm.trigger('form-submit-error', res.err);
          return;
        }

        res.sid = frmData.subjectId;
        res.doulist_id = doulistId;
        res.name = $.trim(encodeHTML(doulistName));

        window.update_collect_state && window.update_collect_state(true);
        frm.trigger('form-submit-success', res);
      });
    }
    return frm;
  }

  doulistDialogForm.initForm = initForm;
})()
;
// ref: docs/widgets/doulist_btn.html

;(function($){
var current_doulist_dialog;

window.hasCancelCollectAction = null;

var params = window.collect_target || {};
if (!params.limit) {
  params.limit = 5;
}
params.start = 0;

/* local-dev
// params.tkind = '1001'
// params.tid = '24879016'
*/

var pureDoulistParams = {
  tkind: params.tkind,
  tid: params.tid,
  start: 0,
  limit: params.limit
};

var searchParams = {
  start: 0,
  limit: params.limit
}

var total;
var pureDoulistTotal;
var searchDoulistTotal;
var status = '';
var pureDoulistStatus = '';
var searchDoulistStatus = '';
var allSubjectDoulsitLoaded = false;
var searchKeyword = ''
var noMoreSearchResult = false;
var inputLock = false;

var DOULIST_ITEM_TMPL = '\
  <div class="dl-item-wrap"\
   data-category="{{category}}"\
   data-doulist-type="{{doulist_type}}"\
   data-is-syncing-from-note="{{is_syncing_from_note}}"\
   data-sync-note-id="{{sync_note_id}}">\
    <input type="radio" value="{{id}}" id="{{id}}" name="dl_id"> \
    <label for="{{id}}"> \
      <span>{{count}}</span> \
      <b data-is-private="{{is_private}}"> \
        <i data-id="{{id}}" data-name="{{name}}" data-is-collected="{{is_collected}}" class="cancel-collect-btn"></i> \
        {{name}} \
      </b> \
    </label> \
  </div>';
var loader = '<div class="loading" style="float: none; width: auto; margin: 4px; background-position: center center;"></div>';

function debounce(func, wait, immediate) {
  var timeout;
  return function() {
    var context = this, args = arguments;
    var later = function() {
      timeout = null;
      if (!immediate) func.apply(context, args);
    };
    var callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
    if (callNow) func.apply(context, args);
  };
};

var DOULIST_CATEGORY_TEXT = {
  'movie': '片单',
  'tv': '片单',
  'book': '书单'
}

function getDigestTypeText(type) {
  var text = type && DOULIST_CATEGORY_TEXT[type] ? DOULIST_CATEGORY_TEXT[type] : '';
  return text;
}

function isStartsWithPrefixWord(str, type) {
  var separator = ['｜', '丨', '|']; // 三种不同类型的分隔符
  return separator.some((sep) => {
    var reg = new RegExp('^' + getDigestTypeText(type) + "\\"  + sep);
    return reg.test(str);
  })
};

function DoulistDialog(node, config) {
  showDoulistDialog(config);
  node.trigger('dialog:show', current_doulist_dialog);

  getAllDoulist(config, function() {
    handleDoulist(config);
    handleNewDoulist(config);
    handleDoulistSearch(config);
    handleCancelCollect();
    handleSelectDoulist(config);
  });
  doulistDialogForm.initForm(current_doulist_dialog);
}

function showDoulistDialog(config) {
  if (current_doulist_dialog) {
    current_doulist_dialog.close();
  }
  config.picture = config.picture || '/pics/doulist_article.png';

  /* local-dev
  // config.cate = '1001'
  */

  var header = config.cate === '1001' ?
    '<h3>选择书单</h3>\
    <input type="button" name="dl_choose" id="dl_new" autocomplete="off" class="lnk-flat" value="创建书单" />' :
    config.cate === '1002' ? 
    '<h3>选择片单</h3>\
    <input type="button" name="dl_choose" id="dl_new" autocomplete="off" class="lnk-flat" value="创建片单" />' :
    '<h3>选择豆列</h3>\
    <input type="button" name="dl_choose" id="dl_new" autocomplete="off" class="lnk-flat" value="创建豆列" />';
  var title = config.cate === '1001' ? '输入新书单名称' : config.cate === '1002' ? '输入新片单名称' : '输入新豆列名称'

  var dialog = current_doulist_dialog = dui.Dialog({
    title: config.cate === '1002' ? '添加到片单' : config.cate === '1001' ? '添加到书单' : '收藏到豆列',
    width: 640,
    cls: 'dialog-doulist',
    content:
      (config.canview === 'False' ?
        '<div class="doulist-ft" style="text-align:left;">啊，该内容你没有权限查看或已被作者删除。</div>' :
        '<form action="" method="post">\
          <div class="doulist-bd">\
            <div class="doulist-preview">\
              <div><img src="{{picture}}" /></div>\
              <p class="item-title">{{title}}</p>\
            </div>\
            <div class="doulist-content">\
              <div class="item">\
                <div class="item-hd">\
                  <input type="text" name="search" class="dl_search" autocomplete="off" placeholder="请输入豆列名称" maxlength="40" />\
                  <a href="javascript: void 0;" class="clear_search">×</a>' +
                  header +
                '</div>\
                <div class="dl-bd">\
                  <div class="dl-item">\
                    <div class="dl_new_title" style="display: none;">\
                      <div class="dl_title_block"> \
                        <input id="dl_title" type="text" class="basic-input dl-title" placeholder="' + title + '" maxlength="40" />\
                      </div> \
                      <div class="dl_action_block"> \
                        <div class="dl_create_option">\
                          <span>隐私设置：</span> \
                          <input id="doulist_is_not_secret" type="radio" name="is_private" value="false" checked /> \
                          <label for="doulist_is_not_secret">所有人可见</label> \
                          <input id="doulist_is_secret" type="radio" name="is_private" value="true" /> \
                          <label for="doulist_is_secret">仅自己可见</label> \
                        </div> \
                        <input type="button" class="lnk-flat dl_new_submit" disabled value="创建" />\
                      </div> \
                    </div>\
                  </div>\
                  <div class="dl-loading">\
                    加载中...\
                  </div>\
                </div>\
              </div>\
              <div class="item">\
                <div class="item-hd">\
                  <h3>推荐语<span>（选填）</span></h3>\
                </div>\
                <textarea id="doulist_item_comment" class="basic-textarea" name="comment" placeholder="告诉大家你添加它的理由吧"></textarea>\
              </div>\
              <input type="hidden" name="dl_cat" value="{{cate}}">\
              <input type="hidden" name="subject_id" value="{{id}}">\
              <input type="hidden" name="subject_kind" value="{{cate}}">\
              <input type="hidden" name="subject_url" value="{{url}}">\
              <input type="hidden" name="subject_is_url_subject" value="{{isurlsubject}}">\
              </div>\
            </div>\
            <div class="doulist-ft">\
              <a target="_blank" href="https://www.douban.com/service/bookmarklet" class="lnk-bookmarklet">小工具：从浏览器直接把网页内容加入豆列</a>\
              <span class="bn-flat cancel_btn"><input type="button" class="j_close_dialog" value="取消"></span>\
              <span class="bn-flat"><input type="submit" class="doulist_submit" value="保存"></span>\
            </div>\
        </form>\
      ').replace(/{{[^{}]+}}/g, function(match) {
        return (encodeHTML(config[match.replace(/[{}]/g, "")]+"").toString());
      })
    }, true).open();

  dialog.update();

  dialog.node.bind('dialog:close', function() {
    dialog.node.remove();
  });

  dialog.node.bind('dialog:change', function() {
    dialog.update();
  });

  // 重置一下各项参数
  params.tkind = config.cate;
  params.tid = config.id;
  params.start = 0;
  pureDoulistParams.tkind = config.cate;
  pureDoulistParams.tid = config.id;
  pureDoulistParams.start = 0;
  searchParams.start = 0;

  status = '';
  pureDoulistStatus = '';
  searchDoulistStatus = '';
  allSubjectDoulsitLoaded = false;

  clearSearch();
}

// 获取包含书单、片单的全部豆列
function getAllDoulist(config, callback) {
  if (config.cate === '1001') {
    getMixedDoulist('book', callback);
  } else if (config.cate === '1002') {
    getMixedDoulist('movie', callback);
  } else {
    getMixedDoulist('common', callback);
  }
}

// 获取已有的片单/书单
function getMixedDoulist(category, callback) {
  var appendPureDoulists = function() {
    if (pureDoulistParams.start >= pureDoulistTotal || pureDoulistStatus === 'pending') {
      return;
    }

    pureDoulistStatus = 'pending';
    $('.dl_exist_select').append(loader);

    asyncRequest(DOULIST_LIST, {
      start: pureDoulistParams.start,
      limit: pureDoulistParams.limit
    })
    .done(function(pureDoulistResp) {
      var DL_TMPL = DOULIST_ITEM_TMPL;

      // 直接请求纯豆列，并且是第一次加载的时候
      if (pureDoulistParams.start === 0 && category === 'common') {
        if (pureDoulistResp.total) {
          var DL_STR = '<div class="dl_exist_select">';
          $(pureDoulistResp.doulist).each(function(i, dl) {
            DL_STR += DL_TMPL.replace(/{{[^{}]+}}/g, function(match) {
              var matched = dl[match.replace(/[{}]/g, "")];
              return matched && encodeHTML(matched.toString()) || "";
            });
          });
          DL_STR += '</div>';
          $('<div />', {'class': 'dl-item dl-item-exist'}).insertAfter($('.dl-item')).append(DL_STR);
        } else {
          $('<div />', {'class': 'dl-item dl-item-exist'}).insertAfter($('.dl-item')).append(
            '<div class="dl_exist_select"><div class="empty-list">还未创建豆列</div></div>'
          );
        }
      } else {
        var DL_STR = '';
        $(pureDoulistResp.doulist).each(function(i, dl) {
          DL_STR += DL_TMPL.replace(/{{[^{}]+}}/g, function(match) {
            var matched = dl[match.replace(/[{}]/g, "")];
            return matched && encodeHTML(matched.toString()) || "";
          });
        });
        $('.dl_exist_select').append(DL_STR);
      }

      pureDoulistParams.start = pureDoulistParams.start + pureDoulistParams.limit;
      pureDoulistTotal = pureDoulistResp.total;
      pureDoulistStatus = 'success';

      $('.dl-item-exist .loading').remove();

      settleDoulistItemStatus(category)

      var dialog = current_doulist_dialog;
      dialog.node.find('form #doulist_item_comment').val(pureDoulistResp.comment);

      if (pureDoulistParams.start >= pureDoulistTotal) {
        $('.dl_exist_select').append('<div style="padding: 14px 0; text-align: center; color: #666;">没有更多了</div>');
      }

      if (category === 'common') {
        callback && callback()
      }

    }).fail(function() {
      $('.dl-loading').text('+_+ 加载失败，请刷新重试');
      pureDoulistStatus = 'error';
      $('.dl-item-exist .loading').remove();
    })
  }

  if (allSubjectDoulsitLoaded || category === 'common') {
    appendPureDoulists();
    return;
  }

  if (params.start >= total || status === 'pending') {
    return;
  }

  status = 'pending';
  $('.dl_exist_select').append(loader);

  asyncRequest(SUBJECT_DOULIST_LIST, {
    start: params.start + getJustCreatedNewListsCount(),
    limit: params.limit,
    tkind: params.tkind,
    tid: params.tid
  }).done(function(resp) {
    var DL_TMPL = DOULIST_ITEM_TMPL;

    // 第一次加载的时候
    if (params.start === 0) {
      if (resp.total) {
        var DL_STR = '<div class="dl_exist_select">';
        $(resp.doulist).each(function(i, dl) {
          DL_STR += DL_TMPL.replace(/{{[^{}]+}}/g, function(match) {
            var matched = dl[match.replace(/[{}]/g, "")];
            return matched && encodeHTML(matched.toString()) || "";
          });
        });
        DL_STR += '</div>';

        $('<div />', {'class': 'dl-item dl-item-exist'}).insertAfter($('.dl-item')).append(DL_STR);
      } else {
        var typeStr = category === 'book' ? '书单' : category === 'movie' ? '片单' : '';
        $('<div />', {'class': 'dl-item dl-item-exist'}).insertAfter($('.dl-item')).append(
          '<div class="dl_exist_select"><div class="empty-list">还未创建' + typeStr + '</div></div>'
        );
      }
    } else {
      var DL_STR = '';
      $(resp.doulist).each(function(i, dl) {
        DL_STR += DL_TMPL.replace(/{{[^{}]+}}/g, function(match) {
          var matched = dl[match.replace(/[{}]/g, "")];
          return matched && encodeHTML(matched.toString()) || "";
        });
      });

      $('.dl_exist_select').append(DL_STR);
    }

    $('.dl_new_title').hide();

    params.start = params.start + params.limit;
    total = resp.total;
    status = 'success';

    $('.dl-item-exist .loading').remove();

    settleDoulistItemStatus(category)

    var dialog = current_doulist_dialog;
    dialog.node.find('form #doulist_item_comment').val(resp.comment);

    callback && callback()

    // 拿到全部的片单/书单后，再去获取纯豆列
    if (params.start >= total) {
      allSubjectDoulsitLoaded = true;

      if (pureDoulistParams.start === 0) {
        $('.dl_exist_select').append('<div class="test" style="font-size: 15px; padding-top: 15px; margin: 10px 0; color: #666; border-top: 1px solid #DFDFDF; ">收藏到豆列</div>')
      }

      appendPureDoulists()
    }
  }).fail(function() {
    $('.dl-loading').text('+_+ 加载失败，请刷新重试');
    status = 'error';
    $('.dl-item-exist .loading').remove();
  });
}


// 针对列表里单个豆列做修改
function settleDoulistItemStatus(targetCategory, isSearch) {
  var dialog = current_doulist_dialog;
  var $items = isSearch ? dialog.node.find('.search-result-list .dl-item-wrap') : dialog.node.find('.dl_exist_select .dl-item-wrap');

  $items.each(function(e, doulist) {
    var $d = $(doulist);
    var doulist_category = $d.attr('data-category');
    var doulist_type = $d.attr('data-doulist-type');
    var is_syncing_from_note = $d.attr('data-is-syncing-from-note');
    var sync_note_id = $d.attr('data-sync-note-id');
    var is_collected = $d.find('.cancel-collect-btn').attr('data-is-collected');

    // 如果已经收藏过了，不能再选择
    // if (is_collected) {
      // $d.find('input').attr('disabled', true)
    // }

    // 不能直接添加到条目豆列
    if (is_syncing_from_note) {
      $d.find('input').attr('disabled', true);
    } 

    if (is_syncing_from_note && sync_note_id && targetCategory === doulist_category) {
        var act = is_collected ? '去移除' : '去添加';
        $d.find('span').html('<a target="_blank" href="//www.douban.com/note/' + sync_note_id + '/edit">' + act + '&gt;</a>');
    }
  })
}

// 获取通过弹窗新建的列表数量，用来在滚动加载时重新计算 start 值
function getJustCreatedNewListsCount() {
  var dialog = current_doulist_dialog;
  var dl_exist = $('.dl_exist_select');
  var count = 0;
  dl_exist.find('.dl-item-wrap').each(function(i, item) {
    if ($(item).hasClass('just-created')) {
      count++
    }
  })
  return count
}

function handleCancelCollect(){
  var $cancelBtn = $('.cancel-collect-btn');
  $cancelBtn.click(function(e){
    e.stopPropagation();
    e.preventDefault();
    if (!confirm("确定要移除吗？")) return;

    var did = $(this).attr('data-id');
    var url = DOULIST_REMOVEITEM.replace('{doulist_id}', did);
    var param = window.collect_target || {};
    var $btn = $(this);
    param.ck = get_cookie('ck');
    asyncRequest(url, param, "post").done(function(res){
      if (res.r === 0) {
        $btn.attr('data-is-collected', 'false');
        $btn.closest('label').find('span').html('');
        var $root = $btn.closest('label').parent();
        $root.find('input[type="radio"]').get(0).checked = false;
        $root.find('input[type="radio"]').attr('disabled', false);
        $root.removeClass('checked_dl');
        window.hasCancelCollectAction = true;
      } else {
        alert("取消收藏时遇到了错误: " + res.err);
      }
    })
  });
}

function handleDoulist(config) {
  var dialog = current_doulist_dialog;
  var dl_new = $('#dl_new');
  var dl_new_title = $('.dl_new_title');
  var dl_title = $('#dl_title');
  var dl_exist = $('.dl-item-exist');
  var dl_id = $('#dl_id');

  dl_new.click(function() {
    var form_error = $('.form-field-error');
    if (dl_new_title.is(':hidden')) {
      form_error.show() && dl_new.val('取消创建');
      dl_new_title.slideDown(function() {
        dl_exist.addClass('fold');
        dl_title.focus();
      });
    } else {
      var typeStr = config.cate === '1001' ? '书单' : config.cate === '1002' ? '片单' : '豆列';
      form_error.hide() && dl_new_title.hide() && dl_new.val('创建' + typeStr) && dl_exist.removeClass('fold');
    }
  });

  // 滚动加载
  // stop page scrolling
  dl_exist.bind('scroll', debounce(function(e) {
    var scrollTop = $(this).scrollTop();
    var scrollHeight = $(this).height();
    var windowHeight = $(".dl_exist_select:visible").height();

    if (scrollTop + scrollHeight + 30 >= windowHeight) {
      e.preventDefault();
      if (dl_exist.find('.search-result-list').size() > 0 && searchDoulistStatus !== '') {
        searchDoulist(config, true)
      } else {
        getAllDoulist(config)
      }
    }
  }, 300));
}

function handleSelectDoulist(config) {
  var dialog = current_doulist_dialog;
  dialog.node.delegate(':radio', 'change', function() {
    var $t = $(this);
    // 排除「新建豆列、片单、书单」表单里的「所有人可见」「仅自己可见」
    if ($t.parents('.dl_create_option').size() > 0) {
      return;
    }
    var did = $t.val();
    var url = DOULIST_COMMENT.replace('{doulist_id}', did);

    // 日记同步的豆列不可选
    if ($t.parent().attr('data-is-syncing-from-note')) {
      return;
    }

    asyncRequest(
      url, {
        /* local-dev
        // sid: '25839662', // movie
        // sid: '24879016', // book
        */
        sid: config.id,
        skind: config.cate
      }
    ).done(function(e){
      dialog.node.find('form #doulist_item_comment').val(e.comment);
    }).fail(function(){
      // ignore
    });
  });
}

function handleNewDoulist(config) {
  var dialog = current_doulist_dialog;
  var dl_new_title = $('.dl_new_title');
  var dl_title = $('#dl_title');
  var dl_new_submit = $('.dl_new_submit');

  dl_title.bind('keyup change', function() {
    if ($.trim(dl_title.val()).length) {
      dl_new_submit.removeAttr('disabled');
    } else {
      dl_new_submit.attr('disabled', true);
    }
  });

  dl_title.bind('keydown', function(e) {
    if (e.keyCode === 13) {
      newListHandler(dialog, dl_new_title, config);
      return false;
    }
  });

  dl_new_submit.click(function() {
    newListHandler(dialog, dl_new_title, config);
  });
}

function renderSearched(res, category) {
  var DL_TMPL = DOULIST_ITEM_TMPL;
  DL_TMPL = DL_TMPL.replace(/value="{{id}}" id="{{id}}"/g, 'value="{{id}}" id="search-{{id}}"').replace(/for="{{id}}"/g, 'for="search-{{id}}"');
  var RESULT = '';
  $(res.doulists).each(function(i, dl) {
    RESULT += DL_TMPL.replace(/{{[^{}]+}}/g, function(match) {
      var matched = dl[match.replace(/[{}]/g, "")];
      return matched && encodeHTML(matched.toString()) || "";
    });
  });

  $('.dl-item-exist .search-result-list').append(RESULT);

  settleDoulistItemStatus(category, true)
}

function handleDoulistSearch(config) {
  var dl_search = $('.dl_search');
  var dl_exist = $('.dl-item-exist');
  var dl_new_title = $('.dl_new_title');
  var dl_new = $('#dl_new');
  var clear_search_btn = $('.clear_search');

  clear_search_btn.click(function() {
    dl_search.val('').change();
    clearSearch()
  });

  dl_search.focus(function() {
    $(this).addClass('expand');
    if (!dl_new_title.is(':hidden')) {
      var form_error = $('.form-field-error');
      var typeStr = config.cate === '1001' ? '书单' : config.cate === '1002' ? '片单' : '豆列';
      form_error.hide() && dl_new_title.hide() && dl_new.val('创建' + typeStr) && dl_exist.removeClass('fold');
    }
  });

  dl_search.bind({
    'compositionstart': function () {
        inputLock = true;
    },
    'compositionend': function () {
        inputLock = false;
    },
    'input': function () {
      setTimeout(() => {
        if (inputLock) return;

        var currenKeyword = $.trim(dl_search.val());
        if (currenKeyword.length && searchKeyword !== currenKeyword) {
          noMoreSearchResult = false;
          searchDoulist(config);
        } else if (currenKeyword.length === 0) {
          clearSearch();
        }
      }, 100);
    }
  })
}

function clearSearch() {
  var dl_search = $('.dl_search');
  var dl_exist = $('.dl-item-exist');
  var clear_search_btn = $('.clear_search');

  $('.no-match-warning').hide();
  dl_exist.find('.dl_exist_select').show();
  dl_exist.find('.search-result-list').remove();
  searchParams.start = 0;
  searchDoulistTotal = null;
  searchDoulistStatus = '';
  // dl_exist.children().show();
  clear_search_btn.hide();
  dl_search.val('');
  searchKeyword = '';
  currenKeyword = '';
  noMoreSearchResult = false;
}

function show_no_match() {
  var dl_exist = $('.dl-item-exist');
  $('.no-match-warning').length ? $('.no-match-warning').show() : dl_exist.before('<p class="no-match-warning">没有找到匹配结果，可以换个关键词试试</p>');
}

function searchDoulist(config, isScrollAppend) {
  var promise = null;
  var dl_search = $('.dl_search');
  var dl_exist = $('.dl-item-exist');
  var dl_new_title = $('.dl_new_title');
  var dl_new = $('#dl_new');
  var clear_search_btn = $('.clear_search');

  var currenKeyword = $.trim(dl_search.val());

  if (promise) {
    promise.abort();
  }
  if (searchDoulistStatus === 'pending' || noMoreSearchResult) {
    return
  }

  $('.no-match-warning').hide();
  if (!isScrollAppend) {
    dl_exist.find('.search-result-list').remove();
  }

  clear_search_btn.hide();
  dl_search.addClass('loading');
  searchKeyword = currenKeyword;
  searchDoulistStatus = 'pending';
  const category = config.cate === '1001' ? 'book' : config.cate === '1002' ? 'movie' : '';

  promise = asyncRequest(
    DOULIST_SEARCH_SELF,
    {
      'limit': 5,
      'start': isScrollAppend ? searchParams.start : 0,
      'q': currenKeyword,
      'category': category
    }
  );
  promise.done(function(res) {
    dl_search.removeClass('loading');
    clear_search_btn.show();
    searchDoulistStatus = 'success';
    if (isScrollAppend) {
      searchParams.start = searchParams.start + searchParams.limit
    }

    if (res && res.doulists && res.doulists.length > 0) {
      if ($('.dl-item-exist .search-result-list').size() === 0) {
        $('.dl-item-exist .dl_exist_select').hide().after('<div class="search-result-list dl_exist_select"></div>')
      }
      renderSearched(res, category)
    } else {
      noMoreSearchResult = true;
      if (searchParams.start === 0) {
        dl_exist.find('.dl_exist_select').hide();
        dl_exist.find('.search-result-list').remove();
        show_no_match();
      } else {
        dl_exist.find('.search-result-list').append('<div style="padding: 14px 0; text-align: center; color: #666;">没有更多了</div>');
      }
    }
  }).fail(function() {
    noMoreSearchResult = true;
    dl_exist.find('.dl_exist_select').hide();
    dl_exist.find('.search-result-list').remove();
    show_no_match();
    dl_search.removeClass('loading');
    clear_search_btn.show();
    searchDoulistStatus = 'error';
  });
}

// 表单验证（创建豆列/片单/书单时）
function newListHandler(dialog, wrap, config) {
  var DL_TMPL = '<div class="just-created dl-item-wrap"><input type="radio" value="{{id}}" id="{{id}}" name="dl_id" checked="checked"><label for="{{id}}"><b data-is-private="{{is_private}}">{{name}}</b></label></div>';
  var dl_title = $('#dl_title');
  var dl_new = $('#dl_new');
  var dl_exist = $('.dl_exist_select');
  var validateRules = {
    '#dl_title': function(e) {
      if (e.val() === '') {
        var typeStr = config.cate === '1001' ? '书单' : config.cate === '1002' ? '片单' : '豆列';
        validateForm.displayError(e, '请给你的' + typeStr + '起一个名称');
        return false;
      }
      return true;
    }
  }
  if (validateForm(wrap, validateRules)) {
    var dl_new_submit = $('.dl_new_submit');
    dl_new_submit.attr('disabled', true);
    var title = $.trim($('#dl_title').val());
    var digestType = config.cate === '1001' ? 'book' : config.cate === '1002' ? 'movie' : '';
    var prefixWord = getDigestTypeText(digestType) + '｜';

    // 如果是书单、片单，标题自动加上前缀
    if (digestType && !isStartsWithPrefixWord(title, digestType)) {
      title = prefixWord + title
    }

    var params = {
      title: title,
      is_private: $('input[name="is_private"]:checked').val(),
    }

    if (config.cate === '1001' || config.cate === '1002') {
      params.category = config.cate === '1001' ? 'book' : 'movie';
    }
    asyncRequest(DOULIST_CREATE, params, 'post')
      .done(function(res) {
        if (res.r) {
          alert(res.err);
          return;
        }

        res.doulist_id = res.id;
        var DL_STR = DL_TMPL.replace(/{{[^{}]+}}/g, function(match) {
          var matched = res[match.replace(/[{}]/g, "")];
          return matched && encodeHTML(matched.toString()) || "";
        });
        var new_dl = $(DL_STR);
        new_dl.prependTo(dl_exist);
        dl_exist.find('.empty-list').remove();

        dl_exist.animate({'scrollTop': 0}, 100);
        dl_new.click();
        dl_title.val('').change();
      })
      .fail(function() {
        alert('网络问题，请稍后重试');
        dl_new_submit.removeAttr('disabled');
      });
  } else {
    dialog.update();
  }
  return wrap;
}

$.fn.doulistDialog = function(options) {
  return new DoulistDialog($(this), options);
};

})(jQuery);


    $(document).delegate('.lnk-doulist-add', 'click', function(e) {
      e.preventDefault();
      if(window._USER_ABNORMAL) {
          show_abnormal && show_abnormal()
          return
      }
      var self = $(this);
      var param = $.extend({'url':''}, $(this).data(), {link: this.href});
      // 兼容jquery 1.8.x
      var newParam = {};
      for (var key in param) {
        if (typeof param[key] === 'number') {
          param[key] = self.attr('data-'+key);
        }
        if (param.hasOwnProperty(key)) {
          newParam[$.camelCase(key)] = param[key];
        }
      }
      self.doulistDialog(newParam);
    });

  });
});
;
            var rec_url = 'https://www.douban.com/share/recommend?';
        ;
                function exp_dialog(e){var t=document.documentElement;return 0-parseInt(e.offsetHeight/2)+(TBWindowMargin=t&&t.scrollTop||document.body.scrollTop)+"px"}function exp_overlay(e){return 0-parseInt(e.offsetHeight/2)+(TBWindowMargin=document.documentElement&&document.documentElement.scrollTop||document.body.scrollTop)+"px"}!function(e,t,n){if("undefined"==typeof DoubanShare){var i={},o=[],a="//img3.doubanio.com/pics/loading.gif",r=".lnk-douban-sharing",d='<div style="padding:30px 0;text-align:center;font-size:14px;color:#060;">分享成功!</div>',l='<div class="rectitle"><span class="gact rr"><a href="#" class="lnk-close">x</a></span><span class="m" >{TITLE}</span></div><div class="bd" style="position:relative;line-height:0;font-size:0;"></div>',c=function(e,t,n){var i;return/device-mobile/i.test(document.documentElement.className)&&(n=.9*document.documentElement.clientWidth),"undefined"!=typeof dui&&dui.Dialog?(i=dui.Dialog({width:n||500,content:e,title:t,isHideClose:0},!0).open(),i.node.addClass("dui-dialog-rec").find(".bd").css({position:"relative",padding:"10px 0 0 0","line-height":0,"font-size":0})):(i=$("#dialog"),0===i.length&&($('<div id="overlay"></div><div id="dialog" class="dialog-shuo"  style="width:'+(n||500)+'px;"></div>').appendTo("body"),i=$("#dialog")),i.html(e),u(),i.find(".lnk-close").click(function(e){e.preventDefault(),s()})),i},u=function(){if("undefined"!=typeof dui&&dui.Dialog&&i.currentDialog)return void i.currentDialog.update();var e=$.browser.msie?-2:16,n=$("#dialog")[0],o=n.offsetWidth,a=(t.body.offsetWidth-o)/2;$("#overlay").css({height:n.offsetHeight+e,width:o+16,left:a+5+"px"}),n.style.left=a+"px"},s=function(){return"undefined"!=typeof dui&&dui.Dialog&&i.currentDialog?(i.currentDialog.close(),void p.fire()):($("#overlay, #dialog").remove(),void p.fire())},f=function(){return o.push(1),"db-sharing-iframe"+o.length},g=function(){var e=t.createElement("iframe");return e.setAttribute("scrolling","no"),e.setAttribute("frameBorder","0"),e.setAttribute("width","100%"),e.setAttribute("allowTransparency","true"),e.src="",e},h=function(e){var t=g(),o=f()+ +new Date+(0|1e6*Math.random()),r=(e.css||"",e.text||"",e.heading||"推荐到豆瓣"),d=e.image?280:230,s=c(l.replace("{TITLE}",r),r,e.width);i.currentDialog=s,$(t).load(function(){try{t.setAttribute("height",t.contentWindow.document.body.clientHeight),u()}catch(e){}}),t.setAttribute("id",o),t.setAttribute("height",e.height||d),t.src=n+$.param(e)+"&alt=xd&callback=DoubanShare.callback&_stamp="+o,s.node?s.node.find(".bd").css("background","url("+a+") 48% 48% no-repeat").eq(0).html("").append(t):s.find(".bd").css("background","url("+a+") 48% 48% no-repeat").html("").append(t),u()},p=function(e){p.callback.push(e)},m=function(e){h(e)},b=function(){$("html").delegate(r,"click",function(e){var t=$(e.currentTarget),n=t.data(),i=["user_id","object_kind","object_id"];if(e.preventDefault(),window._USER_ABNORMAL)return void(show_abnormal&&show_abnormal());for(var o in n)"number"==typeof n[o]&&(n[o]=t.attr("data-"+o));var a={from:"snsrec2share"};for(var r in i){var d=i[r];a[d]=n[d]||0}moreurl&&moreurl(e.currentTarget,a),h(n)})};p.callback=[],p.fire=function(){for(;p.callback.length;)p.callback.pop()()},b(),i.cacheUrl={},i.updateDialog=function(e){var t=i.currentDialog;return t.node?(t.node.find("iframe").css("height",e+"px"),void t.update()):(e&&$("#dialog iframe").css("height",e+"px"),void u())},i.closeDialog=function(){var e=i.currentDialog;e.node?(e.node.find(".hd").hide(),e.node.find(".bd").css("background","none").html(d)):(e.find(".rectitle").hide(),e.find(".bd").css("background","none").html(d)),u(),setTimeout(function(){s()},1e3)},i.share=m,i.onDialogClose=p,e.DoubanShare=i,(new Image).src=a}}(window,document,rec_url);
            ;
            Douban.init_on_blacklist = function(node) {
                $(node).click(function(e) {
                    e.preventDefault()
                    alert('你已被对方加入黑名单，不能转发该日记')
                })
            };
        ;
                !function(e,t,i){function r(e,n){this.config=i.extend(!0,{},a,e);var o=r.serializeOpenGraph();this.pageInfo=i.extend({title:o.title||t.title,url:o.url||t.location.href,pic:("array"===i.type(o.image)?o.image[0]:o.image)||"",desc:o.description||"",site:o.site_name||""},n)}var a={weibo:{appkey:""},douban:{},qq:{},qzone:{}};r.serializeOpenGraph=function(){var e={};i('meta[property^="og:"]').each(function(t,r){r=i(r);var a=r.attr("property").replace(/^og\:/,"");e[a]=r.attr("content")});var t=i('meta[property="og:image"]');return t.length>1&&(e.image=t.map(function(e,t){return i(t).attr("content")}).toArray()),e},r.prototype={constructor:r,set:function(e,t){var r={};r[e]=t,i.extend(this.config,r)},get:function(e){var t=i.extend({},this.pageInfo,this.config[e]);return{douban:{url:"https://www.douban.com/share/service/?"+i.param({href:t.url,name:t.title,image:t.pic,text:t.desc})},weibo:{url:"http://v.t.sina.com.cn/share/share.php?"+i.param({appkey:t.appkey,url:t.url,title:t.title,pic:t.pic})},qq:{url:"http://connect.qq.com/widget/shareqq/index.html?"+i.param({url:t.url,desc:t.title,pics:t.pic,site:t.site})},qzone:{url:"http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?"+i.param({url:t.url,title:t.title,summary:t.desc,pics:t.pic})}}[e]},openInNewWindow:function(t,r){r=r||{};var a=r.width||500,n=r.height||360,o=i.extend({},{width:a,height:n,toolbar:0,location:0,resizable:1,scrollbars:"yes",left:r.left||(screen.width-a)/2,top:r.top||(screen.height-n)/2},r);e.open(t,"SocialSharing",i.param(o).replace(/&/g,","))}},window.SocialSharing=r}(window,document,jQuery);
            ;
            $(function(){function a(a,i){a.find(".sharing-wechat-qrcode").html('<img src="//img3.doubanio.com/dae/qrgen/v2/'+encodeURIComponent(i)+'.png" alt="扫描二维码" />')}var i=$(document),e={weibo:"bshare_sina",qq:"bshare_qqim",qzone:"bshare_qzone"},n={qq:{width:800,height:600},qzone:{width:800,height:600}};i.delegate(".sharing-indicator","click",function(){var i=$(this).closest(".sharing"),e=i.find(".sharing-layer");if(e.hasClass("is-hidden")){var n=i.data("target").url;e.removeClass("is-hidden"),a(e,n)}else e.addClass("is-hidden")}),$("body").bind("click",function(a){if(!$(a.target).hasClass("sharing-indicator")){var i=$(".sharing-layer");i.hasClass("is-hidden")||$(a.target).closest(".sharing-layer").length||i.addClass("is-hidden")}}),$(".sharing-layer").bind("click",function(a){return $(a.target).closest(".sharing-list").length?void $(".sharing-layer").addClass("is-hidden"):void a.stopPropagation()}),i.delegate("[data-share]","click",function(){var a=$(this),i=a.data("share"),s=$(this).closest(".sharing"),t=s.data("target")||{},r=new SocialSharing({weibo:{appkey:"3015934887"}},t),d="https://www.douban.com/link2?type=redir&vendor="+e[i]+"&url="+encodeURIComponent(r.get(i).url);r.openInNewWindow(d,n[i])})});
        ;
    Do = (typeof Do === 'undefined')? $ : Do;
    var div = ".operation-more";
    function addReportLink(){
      $.each($("#comments:not('.sns-comments') .comment-item ".concat(div)), function(i, el){
          if ($(el).find(".comment-report").length==0){
            $(el).append('<div class="comment-report"><a rel="nofollow" href="javascript:void(0)">投诉</a></div>');
          }
      });
    };
    Do(function(){
        $("#comments").delegate(".comment-item", 'mouseenter mouseleave', function (e) {
          switch (e.type) {
            case "mouseenter":
              $(this).find(".comment-report").css('visibility', 'visible');
              break;
            case "mouseleave":
              $(this).find(".comment-report").css('visibility', 'hidden');
              break;
          }
        });
        $("#comments").delegate(".comment-report a", 'click', function (e) {
        e.preventDefault();
        var auditUrl = "http://www.douban.com/misc/audit_report?url=",
            opt = "comment_id";
        var obj = $(e.target).closest('.comment-item');
        var cid = obj.data("cid");
        var url = "https://www.douban.com/group/topic/221530182/?".concat(opt, '=', cid);
        var type = ['comment']
        if (/^\/subject/.test(location.pathname)) {
            type.push('subject')
        }
        generate_report_dialog({report_url: url, type: type});
        });
    addReportLink();
    });
;
    $('.img-uploader-wrapper').bind('click', function(e){
        $(this).find('.img-upload-input').click();
    })
    $('.img-upload-input').bind('click', function(e){
        e.stopPropagation();
    });
    $('.img-upload-input').bind('change', function(){
        if(!this.files.length) return;
        if(!window.FileReader) return;
        var reader = new FileReader();
        var that = this;
        $(this).parent().addClass('added');
        reader.onload = function(){
            $(that).parent().prepend('<img class="img-preview" src="' + reader.result + '">')
        }
        reader.readAsDataURL(this.files[0]);
    })
    $('.remove-img').bind('click', function(e){
        e.preventDefault();
        e.stopPropagation();
        $(this).parent().find('.img-preview').remove();
        $(this).parent().find('.img-upload-input').val('');
        $(this).parent().removeClass('added');
    })
;
                    Do(function(){var a=['<div class="popup-container hide">','<div class="popup-wrap">','<div class="popup-small">','<a class="close"></a>','<p class="popup-info">为确保你的帐户安全，并依《网络安全法》要求，<br/>操作前请先验证手机号。</p>','<div class="popup-btns">',' <a class="btn" href="javascript:;" target="_blank">前往验证</a>',"</div>","</div>","</div>","</div>"].join("");$("body").delegate(".js-verify-account","click",function(e){var t=$(this),i=t;if(window._USER_ABNORMAL)return e.preventDefault(),void(window.show_abnormal&&window.show_abnormal());var o=$(".popup-container"),r=i.attr("data-is-verified"),n=i.attr("data-verify-url");r&&"false"!=r.toLowerCase()?i.attr("href")&&i.attr("href").length&&(location.href=i.attr("href")):(e.preventDefault(),o.size()<1&&($("body").append(a),o=$(".popup-container")),o.find(".btn").attr("href",n),o.removeClass("hide"))}).delegate(".popup-container .close","click",function(){$(".popup-container").addClass("hide")})});
                ;
  ;!function(){function t(t,e){return function(){var i=R[e],o=this;i&&clearTimeout(i),R[e]=setTimeout(function(){t.apply(o,arguments)},300)}}var e=8,i=window.dui||{},o="dui-dialog",n=[],s=null,h=!(!$.browser||!$.browser.msie||"6.0"!==$.browser.version),d=("ontouchstart"in window,{}),a={},c="j_close_dialog",l="dui-dialog",r="dui-dialog-close",u="dui-dialog-shd",f="dui-dialog-content",p="dui-dialog-iframe",m="dui-dialog-msk",g="确定",v="取消",b="提示",w="下载中，请稍候...",y='<div id="{ID}" class="'+l+' {CLS}" style="{CSS_ISHIDE}">                <span class="'+u+'"></span>                <div class="'+f+'">                    {BN_CLOSE}                    {TITLE}                    <div class="bd">{BODY}</div>                </div>            </div>',C='<a href="#" class="'+c+" "+r+'">X</a>',I='<div class="hd"><h3>{TITLE}</h3></div>',k='<iframe class="'+p+'"></iframe>',x='<div class="'+m+'"></div>',T={confirm:{text:g,method:function(t){t.close()}},cancel:{text:v,method:function(t){t.close()}}},S={url:"",nodeId:"",cls:"",content:"",title:b,width:0,height:0,visible:!1,modal:!1,iframe:!1,maxWidth:960,autoupdate:!1,cache:!0,buttons:[],callback:null,dataType:"text",isStick:!1,isHideClose:!1,isHideTitle:!1},H=function(t,e){var i,o={};for(i in e)e.hasOwnProperty(i)&&(o[i]=void 0===t[i]?e[i]:t[i]);return o},D=function(t){for(var e,i=t.elements,o=0,n=[],s={"select-one":function(t){return encodeURIComponent(t.name)+"="+encodeURIComponent(t.options[t.selectedIndex].value)},"select-multiple":function(t){for(var e,i=0,o=[];e=t.options[i++];)e.selected&&o.push(encodeURIComponent(t.name)+"="+encodeURIComponent(e.value));return o.join("&")},radio:function(t){if(t.checked)return encodeURIComponent(t.name)+"="+encodeURIComponent(t.value)},checkbox:function(t){if(t.checked)return encodeURIComponent(t.name)+"="+encodeURIComponent(t.value)}};e=i[o++];)s[e.type]?n.push(s[e.type](e)):n.push(encodeURIComponent(e.name)+"="+encodeURIComponent(e.value));return n.join("&").replace(/\&{2,}/g,"&")},j=function(t){var e=t||{};this.config=H(e,S),this.init()};j.prototype={init:function(){if(this.config)return this.render(),this.bind(),this},render:function(t){var e=this.config,i=e.nodeId||o+n.length;n.push(i);var s=$("body"),h=s.find("."+m),d="object"==typeof e.content?$(e.content).html():e.content;return s.append(y.replace("{ID}",i).replace("{CSS_ISHIDE}",e.visible?"":"visibility:hidden;top:-999em;left:-999em;").replace("{CLS}",e.cls).replace("{TITLE}",I.replace("{TITLE}",e.title)).replace("{BN_CLOSE}",C).replace("{BODY}",d||t||"")),e.modal&&!h.length?(s.append(x),this.msk=$("."+m)):this.msk=h.eq(0),this.nodeId=i,this.node=$("#"+i),this.title=$(".hd",this.node),this.body=$(".bd",this.node),this.btnClose=$("."+r,this.node),this.shadow=$("."+u,this.node),this.iframe=$("."+p,this.node),this.set(e),this},bind:function(){var e=this;return h||$(window).bind({resize:t(function(){e.updatePosition()},"pos"),scroll:t(function(){e.updatePosition()},"pos")}),e.node.delegate("."+c,"click",function(t){e.close(),t.preventDefault()}),e.node.find("."+r).bind("click",function(t){e.close(),t.preventDefault()}),$("body").keypress(function(t){27===t.keyCode&&e.close()}),this},updateSize:function(){var t,i=this.node.width(),o=$(window).width(),n=$(window).height(),s=this.config;$(".bd",this.node).eq(0).css({height:"auto","overflow-x":"visible","overflow-y":"visible"}),t=this.node.height();var h=2*e;return s.maxWidth=Math.min(s.maxWidth,o-h),i>s.maxWidth&&(i=s.maxWidth,this.node.css("width",i+"px")),t>n&&$(".bd",this.node).eq(0).css({height:n-150+"px","overflow-x":"hidden","overflow-y":"auto"}),t=this.node.height(),this.shadow.width(i),this.shadow.height(t),this.iframe.width(i+h).height(t+h),this},updatePosition:function(){if(!this.config.isStick){var t=this.node.width(),i=this.node.height(),o=$(window),n=h?o.scrollTop():0;return this.node.css({left:Math.floor(o.width()/2-t/2)+"px",top:Math.floor(o.height()/2-i/2-e)+n+"px"}),this}},set:function(t){var e,i,o=this.nodeId,n=this.nodeId||n,s=[],h=this,c=function(t){return s.push(0),o+"-"+t+"-"+s.length};if(!t)return this;t.width&&(this.node.css("width",t.width+"px"),this.config.width=t.width),t.height&&(this.node.css("height",t.height+"px"),this.config.height=t.height),$.isArray(t.buttons)&&t.buttons[0]?(i=$(".ft",this.node),e=[],$(t.buttons).each(function(){var t=arguments[1],i=c("bn");"string"==typeof t&&(t=T[t]),t.text&&(t.href?e.push('<a class="'+(t.cls||"")+'" id="'+i+'" href="'+t.href+'">'+t.text+"</a> "):e.push('<span class="bn-flat '+(t.cls||"")+'"><input type="button" id="'+i+'" class="'+n+'-bn" value="'+t.text+'" /></span> '),a[i]=t.method)}),i[0]?i.html(e.join("")):i=this.body.parent().append('<div class="ft">'+e.join("")+"</div>"),this.footer=$(".ft",this.node),$(".ft input, .ft a",this.node).click(function(t){var e=this.id&&a[this.id];if(e)var i=e.call(this,h);i&&(t.preventDefault(),"string"==typeof i&&alert(i))})):(this.footer=$(".ft",this.node),this.footer.html("")),"undefined"!=typeof t.isHideClose&&(t.isHideClose?this.btnClose.hide():this.btnClose.show(),this.config.isHideClose=t.isHideClose),"undefined"!=typeof t.isHideTitle&&(t.isHideTitle?this.title.hide():this.title.show(),this.config.isHideTitle=t.isHideTitle),t.title&&(this.setTitle(t.title),this.config.title=t.title),"undefined"!=typeof t.iframe&&(t.iframe?this.iframe[0]?this.iframe.show():(this.node.prepend(k),this.iframe=$("."+p,this.node)):this.iframe.hide(),this.config.iframe=t.iframe),t.content&&(this.body.html("object"==typeof t.content?$(t.content).html():t.content),this.config.content=t.content),t.url&&(t.cache&&d[t.url]?("text"!==t.dataType&&t.dataType||this.setContent(d[t.url]),t.callback&&t.callback(d[t.url],this)):"json"===t.dataType?(this.setContent(w),this.footer&&this.footer.hide(),$.getJSON(t.url,function(e){h.footer.show(),d[t.url]=e,t.callback&&t.callback(e,h)})):(this.setContent(w),this.footer&&this.footer.hide(),$.ajax({url:t.url,dataType:t.dataType,success:function(e){d[t.url]=e,h.footer&&h.footer.show(),h.setContent(e),t.callback&&t.callback(e,h)}})));var l=t.position;return l&&this.node.css({left:l[0]+"px",top:l[1]+"px"}),"boolean"==typeof t.autoupdate&&(this.config.autoupdate=t.autoupdate),"boolean"==typeof t.isStick&&(t.isStick?this.node.css("position","absolute"):this.node.css("position","fixed"),this.config.isStick=t.isStick),this.update()},update:function(){return this.updateSize(),this.updatePosition(),this},setContent:function(t){return this.body.html(t),this.update()},setTitle:function(t){return $("h3",this.title).html(t),this},submit:function(t){var e=$("form",this.node);e.submit(function(e){e.preventDefault();var i=this.getAttribute("action",2),o=this.getAttribute("method")||"get",n=D(this);$[o.toLowerCase()](i,n,function(e){t&&t(e)},"json")}),e.submit()},open:function(){this.node.appendTo("body").css("visibility","visible").show();var t=this,e=this.config,i=t.body[0];return t.contentHeight=i.offsetHeight,this.watcher=e.autoupdate?setInterval(function(){i.offsetHeight!==t.contentHeight&&(t.update(),t.contentHeight=i.offsetHeight)},100):0,e.modal&&this.msk.show().css({height:$(document).height()}),this},close:function(){return this.node.hide(),this.msk.hide(),this.node.trigger("dialog:close",this),clearInterval(this.watcher),this}},i.Dialog=function(t,e){return!e&&s?t?s.set(t):s:s||e?new j(t):s=new j(t)},window.dui=i;var R={}}();
