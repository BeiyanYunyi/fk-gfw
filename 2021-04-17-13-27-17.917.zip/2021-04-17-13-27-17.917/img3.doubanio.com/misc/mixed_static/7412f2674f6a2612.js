





$(function(){
    var isManager = 'False' === 'True'

    $("#joingroupbtn").click(function(e){
        url = "/j/group/" + $(this).attr("name") + "/join";
        if(window._USER_ABNORMAL) {
            e.preventDefault()
            window.show_abnormal && window.show_abnormal()
            return
        }
        $.post_withck(url, {},
            function(sjson){
                var ret = eval("(" + sjson + ")");
                $("#joingroupbtn").hide();
                if (ret.result=="toomany"){
                    $("#replysect").html('<p class="attn" align="right">你已经加入了500个小组，无法再加入更多小组。</p>');
                }else{
                    $("#replysect").html('<br/><h2>你现在加入了这个小组，可以发表回应</h2><div class="txd comment-form"><form name="comment_form" method="post" action="add_comment"><textarea name="rv_comment" rows="8" cols="54"></textarea><br/><input type="hidden" name="start" value="0"/><span class="bn-flat-hot rr"><input type="submit" value="发送"/></span><span><label class="pl share-label share-shuo"><input type="checkbox" name="sync_to_mb"/>转发到广播 </label> </span></form></div>');
                }
            });
        return false;
    });

    $(".topic-reply li").find('.operation-more').hide()
    $(".topic-reply li").find('.lnk-show-memberstats').remove();

    $(".topic-reply li").bind('mouseenter mouseleave click', function (e) {
        var $this = $(this),
            comment_user_id = $this.find(".operation_div").attr("id"),
            can_delete = 0;
        if (comment_user_id == 59561039){
            can_delete = 1;
        }
        if (can_delete==1){
            $this.find(".lnk-delete-comment").show();
        } else {
            $this.find(".lnk-delete-comment").remove()
        }
        if (can_delete !== 1 && !isManager) {
            $this.find('.lnk-opt-line').remove()
        } else {
            $this.find('.lnk-opt-line').show()
        }
        switch (e.type) {
            case "mouseenter":
                $this.find(".operation-more").show();
                break;
            case "mouseleave":
                $this.find(".operation-more").hide();
                break;
        }
    });

    $(function(){
        var req_user_id = 59561039;
        var expand_text_length = 90;

        // 主评论的 private
        $(".comment-private").each(function(index, el){
            var $el = $(el);
            var author_id = $el.data('author-id');
            if(author_id === req_user_id){
            $el.addClass('comment-private-author');
            }
        });

        // 引用评论的 private
        $(".reply-quote-private .reply-quote-content").each(function(index, el){
            var $el = $(el);
            var author_id = $el.data('author-id');

            if(author_id === req_user_id){
            var real_text = $el.find('.real-text').html();

            $el.find('.all').html(real_text);
            $el.find('.short').html(real_text.slice(0, expand_text_length));

            if(real_text.length > expand_text_length){
                $el.find('.toggle-reply').html('<span class="expaned">...</span>');
            }
            }
        });

    });


    $('body').delegate('.reply-comment .lnk-close', 'click', function(e){
      e.preventDefault();
      $(this).parent().remove();
    });

});

$(".reply-quote-private").mouseenter(function() {
    $(this).find('.private-msg').show()
}).mouseleave(function() {
    $(this).find('.private-msg').hide()
})
