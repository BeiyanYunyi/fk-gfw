
;(function() {
  var rootNode = document.getElementById(_ED_ROOT);
  rootNode.style.display = 'none';
  window._DETECT_BROWSER = function(ok, msg) {
    rootNode.style.display = 'block';
    if(!ok) {
      rootNode.innerHTML = msg;
      return;
    }
    rootNode.style.display = 'block';
    Do('editor');
  }
})();
!function(e){function t(r){if(n[r])return n[r].exports;var o=n[r]={i:r,l:!1,exports:{}};return e[r].call(o.exports,o,o.exports,t),o.l=!0,o.exports}var n={};t.m=e,t.c=n,t.d=function(e,n,r){t.o(e,n)||Object.defineProperty(e,n,{enumerable:!0,get:r})},t.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},t.t=function(e,n){if(1&n&&(e=t(e)),8&n)return e;if(4&n&&"object"==typeof e&&e&&e.__esModule)return e;var r=Object.create(null);if(t.r(r),Object.defineProperty(r,"default",{enumerable:!0,value:e}),2&n&&"string"!=typeof e)for(var o in e)t.d(r,o,function(t){return e[t]}.bind(null,o));return r},t.n=function(e){var n=e&&e.__esModule?function(){return e.default}:function(){return e};return t.d(n,"a",n),n},t.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},t.p="",t(t.s=511)}({508:function(e,t,n){},511:function(e,t,n){"use strict";n.r(t),n(508);for(var r,o=function(e){for(var t,n=e.split("-"),r=[];t=n.shift();)t.length&&r.push(t.charAt(0).toUpperCase()+t.substr(1));return r.join("")},i=([{name:"json",isRequired:!0,test:function(){return"JSON"in window&&"parse"in JSON&&"stringify"in JSON}},{name:"svg",isRequired:!0,test:function(){return!!document.createElementNS&&!!document.createElementNS("http://www.w3.org/2000/svg","svg").createSVGRect}},{name:"xhr2",isRequired:!0,test:function(){return"XMLHttpRequest"in window&&"withCredentials"in new XMLHttpRequest}},{name:"localstorage",test:function(){var e="_detech_editor_browser_compatibility";try{return localStorage.setItem(e,e),localStorage.removeItem(e),!0}catch(e){return!1}}},{name:"multiplefile",isRequired:!0,test:function(){return"multiple"in document.createElement("input")}},{name:"fullscreen",test:function(){return function(e,t){for(var n,r=["moz","webkit","ms",""];n=r.shift();)if(void 0!==t[n=n?n+o(e):e])return!0;return!1}("fullscreenEnabled",document)}},{name:"bloburl",test:function(){return"URL"in window&&"function"==typeof window.URL.createObjectURL}},{name:"csstransform",isRequired:!0,test:function(){return function(e){for(var t,n=["Moz","Webkit","ms",""],r=document.createElement("div");t=n.shift();)if(t=t?t+o(e):e,void 0!==r.style[t])return!0;return!1}("transform")}}]),u=!0,c={},s=0,a=i.length;s<a;s++)r=i[s].test(),c[i[s].name]=r,!r&&i[s].isRequired&&(u=!1);var f={ok:u,result:c};window._DETECT_BROWSER&&window._DETECT_BROWSER(f.ok,f.result)}});
