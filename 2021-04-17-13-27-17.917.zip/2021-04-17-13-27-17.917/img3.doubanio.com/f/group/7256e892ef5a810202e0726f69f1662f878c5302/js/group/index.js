;(function() {
  $('.btn-cancel-join').click(function(e) {
    e.preventDefault()
    var _this = this
    dui.Dialog({
      content: '确定取消入组申请吗',
      buttons: [{
        text: '确定',
        method: function() {
          window.location.href = _this.href
        }
      }, {
        text: '不了',
        method: function() {
          dui.Dialog().close()
        }
      }],
    }).open()
  })
  
  var query = window.location.search.slice(1).split('&').reduce((acc, val) => {
    let item = val.split('=')
    acc[item[0]] = item[1]
    return acc
  }, {})
  if (query.create_topic === '1' && query.gallery_topic_id) {
    dui.Dialog({
      content: '这个话题是由小组发起的，加入该小组才能参与话题',
      buttons: [{
        text: '确定',
        method: function() {
          dui.Dialog().close()
        }
      }]
    }).open()
  }
})()
